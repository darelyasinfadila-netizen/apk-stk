STK SUPER APP - ANDROID PROJECT

Ini adalah project sumber Android native (Kotlin + Jetpack Compose), bukan file APK yang sudah dikompilasi.

CARA MEMBUAT APK:
1. Buka project ini di Android Studio pada komputer.
2. Tunggu Gradle Sync selesai (perlu internet untuk mengunduh dependensi).
3. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK debug akan muncul di app/build/outputs/apk/debug/app-debug.apk.

CATATAN:
- Data aplikasi ini disimpan lokal pada perangkat.
- Belum ada database online bersama, login/admin server, sinkronisasi antaranggota, atau push notification.
- Jangan gunakan untuk menyimpan data sensitif sebelum backend dan autentikasi server dibuat.
- Nama aplikasi: STK SUPER APP. Package: com.sptra.thekorz.
