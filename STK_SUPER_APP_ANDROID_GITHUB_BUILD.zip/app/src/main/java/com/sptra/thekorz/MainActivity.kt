package com.sptra.thekorz

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject

private val Navy = Color(0xFF07182C)
private val Panel = Color(0xFF102943)
private val Cyan = Color(0xFF78D9FF)
private val Pale = Color(0xFFEEF8FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("stk_data", MODE_PRIVATE)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Cyan, background = Navy, surface = Panel,
                onPrimary = Navy, onBackground = Pale, onSurface = Pale
            )) {
                STKApp(
                    load = { key -> prefs.getString(key, "[]") ?: "[]" },
                    save = { key, value -> prefs.edit().putString(key, value).apply() }
                )
            }
        }
    }
}

@Composable
fun STKApp(load: (String) -> String, save: (String, String) -> Unit) {
    val sections = listOf(
        "Dashboard", "Announcement", "Member Center", "Recruitment",
        "Event Center", "Task Manager", "Voting", "Suggestion Box",
        "Gallery", "Academy", "Admin Panel"
    )
    val keys = listOf("", "announce", "members", "recruit", "events", "tasks", "votes", "suggest", "gallery", "academy", "")
    var selected by remember { mutableIntStateOf(0) }
    var refresh by remember { mutableIntStateOf(0) }
    var showForm by remember { mutableStateOf(false) }
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    val key = keys[selected]
    val data = remember(selected, refresh) {
        if (key.isBlank()) JSONArray() else try { JSONArray(load(key)) } catch (_: Exception) { JSONArray() }
    }

    Row(Modifier.fillMaxSize().background(Navy)) {
        Column(Modifier.width(76.dp).fillMaxHeight().background(Color(0xFF0A2038)).padding(vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally) {
            Text("STK", color = Cyan, fontWeight = FontWeight.Black, fontSize = 19.sp, modifier = Modifier.padding(10.dp))
            sections.forEachIndexed { index, name ->
                val icon = when(index) {
                    0 -> Icons.Default.Home; 1 -> Icons.Default.Campaign; 2 -> Icons.Default.People
                    3 -> Icons.Default.Assignment; 4 -> Icons.Default.Event; 5 -> Icons.Default.Checklist
                    6 -> Icons.Default.HowToVote; 7 -> Icons.Default.Mail; 8 -> Icons.Default.Photo
                    9 -> Icons.Default.School; else -> Icons.Default.Settings
                }
                Column(Modifier.fillMaxWidth().clickable { selected = index; showForm = false }
                    .background(if (selected == index) Panel else Color.Transparent)
                    .padding(vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(icon, contentDescription = name, tint = if(selected == index) Cyan else Color.LightGray)
                    Text(name.substringBefore(" "), color = if(selected == index) Pale else Color.LightGray, fontSize = 9.sp)
                }
            }
        }
        Column(Modifier.fillMaxSize().padding(18.dp)) {
            Text("SPTRA THE KORZ", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Text(sections[selected], color = Pale, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
            Text("STK • OFFICIAL MEMBER PORTAL", color = Color(0xFFA8C3D8), fontSize = 11.sp)
            Spacer(Modifier.height(16.dp))
            if (selected == 0) {
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(20.dp)) {
                        Text("WELCOME TO", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("STK SUPER APP", color = Pale, fontSize = 27.sp, fontWeight = FontWeight.Black)
                        Text("Satu tempat untuk informasi, anggota, seleksi, dan aktivitas Marga STK.", color = Color(0xFFA8C3D8))
                    }
                }
                Spacer(Modifier.height(14.dp))
                Text("MENU UTAMA", color = Cyan, fontWeight = FontWeight.Bold)
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    itemsIndexed(sections.drop(1)) { i, label ->
                        Card(Modifier.fillMaxWidth().clickable { selected = i + 1 }, colors = CardDefaults.cardColors(containerColor = Panel)) {
                            Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(label, color = Pale, fontWeight = FontWeight.SemiBold)
                                Spacer(Modifier.weight(1f)); Icon(Icons.Default.ChevronRight, null, tint = Cyan)
                            }
                        }
                    }
                }
            } else if (selected == 10) {
                Text("Ringkasan data tersimpan di perangkat ini.", color = Color(0xFFA8C3D8))
                Spacer(Modifier.height(12.dp))
                keys.filter { it.isNotBlank() }.forEach { k ->
                    val count = try { JSONArray(load(k)).length() } catch (_: Exception) { 0 }
                    Text("$k  •  $count item", color = Pale, modifier = Modifier.padding(7.dp))
                }
                Text("Panel ini belum dilindungi login admin server. Jangan simpan data rahasia.", color = Cyan, fontSize = 12.sp)
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Daftar ${sections[selected]}", color = Color(0xFFA8C3D8), modifier = Modifier.weight(1f))
                    Button(onClick = { title = ""; body = ""; showForm = true }) { Text("Tambah") }
                }
                Spacer(Modifier.height(10.dp))
                if (showForm) {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                        Column(Modifier.padding(14.dp)) {
                            OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Judul / Nama") }, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(value = body, onValueChange = { body = it }, label = { Text("Keterangan") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = {
                                    if (title.isNotBlank() && body.isNotBlank()) {
                                        val arr = JSONArray(load(key))
                                        arr.put(JSONObject().put("title", title).put("body", body).put("date", System.currentTimeMillis()))
                                        save(key, arr.toString()); refresh++; showForm = false
                                    }
                                }) { Text("Simpan") }
                                OutlinedButton(onClick = { showForm = false }) { Text("Batal") }
                            }
                        }
                    }
                }
                if (data.length() == 0) {
                    Box(Modifier.fillMaxWidth().padding(28.dp), contentAlignment = Alignment.Center) {
                        Text("Belum ada data. Tekan Tambah untuk membuat item.", color = Color(0xFFA8C3D8))
                    }
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        items(data.length()) { i ->
                            val item = data.optJSONObject(data.length() - 1 - i) ?: JSONObject()
                            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(15.dp)) {
                                Column(Modifier.padding(15.dp)) {
                                    Text(item.optString("title"), color = Pale, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                    Spacer(Modifier.height(5.dp))
                                    Text(item.optString("body"), color = Color(0xFFA8C3D8))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
